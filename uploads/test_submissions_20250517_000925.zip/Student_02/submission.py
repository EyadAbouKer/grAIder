def sum_even(numbers):
    return sum(x for x in numbers if x % 2 == 0)