def sum_even(numbers):
    return sum(numbers)